from collections import Counter
import numpy as np
import torch
from math import ceil

class Jeu_Zatzy:
    def __init__(self):
        self.nbDes = 5
        self.lSections = ["Ones", "Twos", "Threes", "Fours", "Fives", "Sixes"]#, "3 of kind", "4 of kind", "Small Straight", "Large Straight", "Full House", "Chance", "Yatzy"]          
        self.lSectionsFin = ["Total 1", "Bonus", "Total Final"]
        self.dicoSections = {# section : (condition, score, scoreMax)
                          "Ones" : (lambda lDes : any(de==1 for de in lDes), lambda lDes : sum(1 for de in lDes if de==1), 5*1),
                          "Twos" : (lambda lDes : any(de==2 for de in lDes), lambda lDes : sum(2 for de in lDes if de==2), 5*2),
                          "Threes" : (lambda lDes : any(de==3 for de in lDes), lambda lDes : sum(3 for de in lDes if de==3), 5*3),
                          "Fours" : (lambda lDes : any(de==4 for de in lDes), lambda lDes : sum(4 for de in lDes if de==4), 5*4),
                          "Fives" : (lambda lDes : any(de==5 for de in lDes), lambda lDes : sum(5 for de in lDes if de==5), 5*5),
                          "Sixes" : (lambda lDes : any(de==6 for de in lDes), lambda lDes : sum(6 for de in lDes if de==6), 5*6),
                          "Total 1" : (lambda grille, iJ : all(grille[section1][iJ] is not None for section1 in ["Ones", "Twos", "Threes", "Fours", "Fives", "Sixes"]), lambda grille, iJ : sum(grille[section1][iJ] for section1 in ["Ones", "Twos", "Threes", "Fours", "Fives", "Sixes"]), 5*(6*7)//2),
                          "Bonus" : (lambda grille, iJ : grille["Total 1"][iJ] is not None, lambda grille, iJ : 35 if grille["Total 1"][iJ] >= 63 else 0),
                          "3 of kind" : (lambda lDes : any(v>=3 for v in Counter(lDes).values()), lambda lDes : sum(de for de in lDes), 6*7//2),
                          "4 of kind" : (lambda lDes : any(v>=4 for v in Counter(lDes).values()), lambda lDes : sum(de for de in lDes), 6*7//2),
                          "Small Straight" : (lambda lDes : set(lDes)=={1,2,3,4} or set(lDes)=={2,3,4,5} or set(lDes)=={3,4,5,6}, lambda lDes : 30, 30),
                          "Large Straight" : (lambda lDes : set(lDes)=={1,2,3,4,5} or set(lDes)=={2,3,4,5,6}, lambda lDes : 40, 40),
                          "Full House" : (lambda lDes : 2 in Counter(lDes).values() and 3 in Counter(lDes).values(), lambda lDes : 25, 25),
                          "Chance" : (lambda lDes : True, lambda lDes : sum(de for de in lDes), 6*7//2),
                          "Yatzy" : (lambda lDes : len(set(lDes))==1, lambda lDes : 50, 50),
                          "Total Final" : (lambda grille, iJ : all(grille[section1][iJ] is not None for section1 in self.lSections+["Bonus"]), lambda grille, iJ : sum(grille[section1][iJ] for section1 in self.lSections+["Bonus"]), None)}

    def evaluation(self, lJoueurs, nbParties):
        nbJoueurs = len(lJoueurs)
        lSommeScores = [0]*nbJoueurs
        for iP in range(1, nbParties+1):
            print('\r' + ' '*100 + '\r' + f"Partie {iP} ({100*iP/nbParties:.2f}%)", end='', flush=True)
            lScores = self.partie(lJoueurs=lJoueurs)
            for iJ in range(nbJoueurs):
                lSommeScores[iJ] += lScores[iJ]
        lScoresMoyens = [sommeScores/nbParties for sommeScores in lSommeScores]
        print('\n', ' - '.join(map(lambda scoreM : f"{scoreM:.2f}", lScoresMoyens)))

    def partie(self, lJoueurs):
        nbJoueurs = len(lJoueurs)
        grille = {section : [None]*nbJoueurs for section in self.lSections+self.lSectionsFin}
        for iT in range(len(self.lSections)):
            listeLDes = [np.random.randint(1,7,(3,)) for _ in range(self.nbDes)]
            lJoueurs2 = [[joueur, iJ, [0]*self.nbDes, False] for iJ,joueur in enumerate(lJoueurs)] #iJ, lID, fini
            iR = 1
            while iR <= 3:
                for i, (joueur, iJ, lID, _) in enumerate(lJoueurs2):
                    #print(iT, iJ, lID)
                    type, action = joueur.fonction_action(self.dicoSections, grille, self.lSections, iJ, self.caracteristiques(grille, iJ, [lDes[iD] for lDes, iD in zip(listeLDes, lID)]), iT, iR)
                    if type == "Relancer":
                        for iD in action:
                            lID[iD] += 1
                    else :
                        section, score = action
                        grille[section][iJ] = score
                        lJoueurs2[i][3] = True #fini
                iR += 1
                lJoueurs2 = [[joueur, iJ, lID, fini] for joueur, iJ, lID, fini in lJoueurs2 if not fini]
            assert not lJoueurs2, f"lJoueurs2 pas vide à iT = {iT} : {lJoueurs2}"

        #print(*grille.items(), sep='\n')
        for iJ in range(nbJoueurs):
            for section in self.lSections:
                if grille[section][iJ] is None:
                    grille[section][iJ] = 0
                    print("Erreur 1 (voir)", section, grille[section][iJ])
            for sectionFin in self.lSectionsFin:
                if self.dicoSections[sectionFin][0](grille, iJ):
                    grille[sectionFin][iJ] = self.dicoSections[sectionFin][1](grille, iJ)
                else :
                    print("Erreur 2 (voir)", sectionFin)
        #self.afficher_grille(grille)
        return grille["Total Final"]

    def afficher_grille(self, grille):
        tailleMaxCles = max(len(k) for k in grille.keys())
        tailleMaxValues = max(max(len(str(v)) for v in lV) for lV in grille.values())
        for k,lV in grille.items():
            print(f"{k : ^{tailleMaxCles}} => {' - '.join(map(lambda v : f"{v : ^{tailleMaxValues}}" ,lV))}")

    def caracteristiques(self, grille, iJ, lDes):
        lCaracteristiques = []
        for section in self.lSections:
            if grille[section][iJ] is None:
                if self.dicoSections[section][0](lDes):
                    lCaracteristiques.append((section, self.dicoSections[section][1](lDes)))
        return lCaracteristiques
    
    def GA(self, nbJoueurs, nbGenerations, nbParties, lNbNoeuds):
        def generer_nn_mutation(dico, tM):
            dico2 = {}
            for k,v in dico.items():
                bruit = torch.randn_like(v)*tM
                v2 = v + bruit
                dico2[k] = v2
            return dico2
        lJoueurs = [Joueur_GA(lNbNoeuds) for _ in range(nbJoueurs)]
        tauxSurvivant = 0.2
        nbSurvivants = max(1, round(tauxSurvivant*nbJoueurs))
        nbMutes = ceil((nbJoueurs-nbSurvivants) / nbSurvivants)

        tauxMutationInit, tauxMutationFin = 0.2, 0.001
        decroissanceTM = (tauxMutationFin-tauxMutationInit) / (nbGenerations-1)
        tM = tauxMutationInit

        for iG in range(1, nbGenerations+1):
            for joueur in lJoueurs:
                joueur.sommeScores = 0
            for iP in range(1, nbParties+1):
                print('\r' + ' '*100 + '\r' + f"GA : Génération {iG} ({100*iG/nbGenerations:.2f}%) || Partie {iP} ({100*iP/nbParties:.2f}%)", end='', flush=True)
                lScores = self.partie(lJoueurs)
                for iJ, score in enumerate(lScores):
                    lJoueurs[iJ].sommeScores += score
            for joueur in lJoueurs:
                joueur.scoreMoyen = joueur.sommeScores / nbParties
            lJoueurs.sort(key=lambda joueur : joueur.scoreMoyen, reverse=True)
            for iS, survivant in enumerate(lJoueurs[:nbSurvivants]):
                iD = min(nbJoueurs-1, nbSurvivants + iS*nbMutes)
                for iM, perdant in enumerate(lJoueurs[iD : min(nbJoueurs-1, iD+nbMutes)+1]):
                    perdant.NN.load_state_dict(generer_nn_mutation(survivant.NN.state_dict(), tM))
            tM -= decroissanceTM

            print('\n', ' - '.join(map(lambda scoreM : f"{scoreM:.2f}", [joueur.scoreMoyen for joueur in lJoueurs[:10]])))
        with open("GA_jeu.txt", 'w') as fichier:
            fichier.write(str(lJoueurs[0].NN.state_dict()))
        return lJoueurs






    
class Joueur_Greedy:
    def __init__(self):
        pass
    def fonction_action(self, dicoSection, grille, lSections, iJ, lActions, iT, iR):
        if iR < 3:
            return ("Relancer", np.random.choice(range(5), size=5, replace=False))
        elif lActions :
            meilleurScore, meilleurIAction = -float("inf"), 0
            for iA, (section, score) in enumerate(lActions):
                if score > meilleurScore:
                    meilleurScore = score
                    meilleurIAction = iA
            return ("None", lActions[meilleurIAction])  
        else :
            return ("None", (np.random.choice([section for section in lSections if grille[section][iJ] is None]), 0))






class Joueur_GA:
    def __init__(self, lNbNoeuds):
        lCouches = []
        for i in range(1, len(lNbNoeuds)):
            lCouches.append(torch.nn.Linear(lNbNoeuds[i-1], lNbNoeuds[i]))
            if i+1 < len(lNbNoeuds):
                lCouches.append(torch.nn.LeakyReLU())
        self.NN = torch.nn.Sequential(*lCouches)

        self.sommeScores, self.scoreMoyen = 0, 0
    
    def fonction_action(self, dicoSection, grille, lSections, iJ, lActions, iT, iR):
        if not lActions:
            return ("None", (np.random.choice([section for section in lSections if grille[section][iJ] is None]), 0))
        
        #lMasques = [1 if grille[section][iJ] is None else 0 for section in lSections]
        dicoScores = {section : 0 for section in lSections}
        for section, score in lActions:
            dicoScores[section] = score/dicoSection[section][2] #/scoreMax
        lScores = [dicoScores[section] for section in lSections]
        sommeScores1 = sum(grille[section1][iJ] if grille[section1][iJ] is not None else 0 for section1 in ["Ones", "Twos", "Threes", "Fours", "Fives", "Sixes"])
        manqueBonus = max(0, 63-sommeScores1)
        lInput = torch.tensor(lScores + [iT/len(lSections), manqueBonus/63], dtype=torch.float32)
        
        lOutput = self.NN(lInput)
        sSectionsActions = set([section for section,score in lActions])
        tMasque2 = torch.tensor([1 if section in sSectionsActions else 0 for section in lSections], dtype=torch.int8)
        lOutput[tMasque2 == 0] = -float("inf")
        lProbas = torch.softmax(lOutput, dim=0)
        section = lSections[torch.argmax(lProbas)]

        for i, (sectionAction, scoreAction) in enumerate(lActions):
            if sectionAction == section:
                return ("None", (sectionAction, scoreAction))
        print("Erreur 3 (voir)")
        return ("None", lActions[0])








jeu = Jeu_Zatzy()
lJoueurs = [Joueur_Greedy() for _ in range(5)] + jeu.GA(nbJoueurs=100, nbGenerations=500, nbParties=100, lNbNoeuds=[8, 4, 4, 6])[:10]
jeu.evaluation(lJoueurs=lJoueurs, nbParties=1000)