import numpy as np
from time import monotonic
from collections import Counter

def generer_toutes_combinaisons(taille, nbMin, nbMax):
    lCombinaisons = []
    combinaison = [nbMin]*taille
    while combinaison[0] <= nbMax:
        lCombinaisons.append(combinaison.copy())
        combinaison[-1] += 1
        i = taille-1
        while i > 0 and combinaison[i] > nbMax:
            combinaison[i] = nbMin
            i -= 1
            combinaison[i] += 1
    return lCombinaisons

lSections = [("Ones", lambda lDes : sum(1 for de in lDes if de==1)),
             ("Twos", lambda lDes : sum(2 for de in lDes if de==2)),
             ("Threes", lambda lDes : sum(3 for de in lDes if de==3)),
             ("Fours", lambda lDes : sum(4 for de in lDes if de==4)),
             ("Fives", lambda lDes : sum(5 for de in lDes if de==5)),
             ("Sixes", lambda lDes : sum(6 for de in lDes if de==6)),
             ("3 of kind", lambda lDes : sum(de for de in lDes) if any(v>=3 for v in Counter(lDes).values()) else 0),
             ("4 of kind", lambda lDes : sum(de for de in lDes) if any(v>=4 for v in Counter(lDes).values()) else 0),
             ("Small Straight", lambda lDes : 30 if set(lDes)=={1,2,3,4} or set(lDes)=={2,3,4,5} or set(lDes)=={3,4,5,6} else 0),
             ("Large Straight", lambda lDes : 40 if set(lDes)=={1,2,3,4,5} or set(lDes)=={2,3,4,5,6} else 0),
             ("Full House", lambda lDes : 25 if 2 in Counter(lDes).values() and 3 in Counter(lDes).values() else 0),
             ("Chance", lambda lDes : sum(de for de in lDes)),
             ("Yatzy", lambda lDes : 50 if len(set(lDes))==1 else 0)]


N = 13
lCombinaisonsSections = generer_toutes_combinaisons(taille=N, nbMin=0, nbMax=1)
dicoSections = {tuple(combinaison) : None for combinaison in lCombinaisonsSections}
dicoSections[(0,)*N] = 0
dicoTypeSection = {n : [] for n in range(0, N+1)}
for combinaison in lCombinaisonsSections:
    dicoTypeSection[sum(combinaison)].append(combinaison)

lCombinaisonsDes = generer_toutes_combinaisons(taille=5, nbMin=1, nbMax=6)

for iT in range(1, N+1):
    print('\r' + ' '*100 + '\r' + f"Tour {iT} ({100*iT/N:.2f}%)", end='', flush=True)
    for combinaisonSection in dicoTypeSection[iT]:
        sommeScores = 0
        for combinaisonDes in lCombinaisonsDes:
            scoreMax = 0
            for iS, plein in enumerate(combinaisonSection):
                if plein:
                    combinaisonSection2 = combinaisonSection.copy()
                    combinaisonSection2[iS] = False
                    scoreMax = max(scoreMax, dicoSections[tuple(combinaisonSection2)] + lSections[iS][1](combinaisonDes))
            sommeScores += scoreMax
        scoreMoyen = sommeScores / len(lCombinaisonsDes)
        dicoSections[tuple(combinaisonSection)] = scoreMoyen
print(*dicoSections.items(), sep='\n')


"""
for N in range(1, 10):
    tAvant = monotonic()
    formatNb = f"0{N}b"
    lEtats = [[int(bit) for bit in format(nb, formatNb)] for nb in range(0, 2**N)]
    dicoEtats = {} #etat : (score, [lCat, lEtat2])
    for etat in lEtats:
        lCat = [i for i,bit in enumerate(etat) if bit]
        lEtats2 = []
        for i in lCat:
            lEtats2.append(etat.copy())
            lEtats2[-1][i] = False
        dicoEtats[tuple(etat)] = [None, [(i, tuple(etat2)) for i,etat2 in zip(lCat, lEtats2)]]
    dicoTypeEtats = {n : [] for n in range(N+1)}
    for etat in lEtats:
        dicoTypeEtats[sum(etat)].append(tuple(etat))
    dicoEtats[(0,)*N][0] = 0

    formatDes = f"05n"
    listeLDes = generer_toutes_combinaisons(5, 1, N)
    listeLDes2 = [[sum(de for de in lDes if de==i) for i in range(1, N+1)] for lDes in listeLDes]
    lCatMoyen = [None]*(N+1)
    for n in range(1, N+1):
        lSommeCat = [0]*N
        for etat in dicoTypeEtats[n]:
            sommeScores = 0
            for lDes in listeLDes2:
                scoreMax = 0
                iMax = 0
                for iCat,etat2 in dicoEtats[etat][1]:
                    score2 = dicoEtats[etat2][0]+lDes[iCat]
                    if score2 > scoreMax:
                        scoreMax = score2
                        iMax = iCat
                sommeScores += scoreMax
                lSommeCat[iMax] += 1
            scoreMoyen = sommeScores / len(listeLDes)
            dicoEtats[etat][0] = scoreMoyen
        lCatMoyen[n]  = [round(sommeCat/len(dicoTypeEtats[n]*len(listeLDes)),2) for sommeCat in lSommeCat]

    print(f"N = {N} : Temps = {monotonic()-tAvant:.5f}s || Score = {dicoEtats[(1,)*N][0]:.3f} || nbCombinaisons = {len(listeLDes)}")
    print(*lCatMoyen, sep='\n')
    #for k,v in dicoEtats.items():
        #print(k, v[0])

"""